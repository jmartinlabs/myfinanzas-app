SPEC22 · E4.2 — Capturas rev3 (wireframes ajustados)

Contenido:
- HTML autocontenido rev3.
- W2/W5, W11–W16 a 1440/390 según su diseño.
- Estados: vacío, carga, error y sesión expirada (1440/390).
- W15b: revisión obsoleta, recálculo y borrador conservado (1440/390).
- D1, D2 y D3: bloqueos y avisos (1440/390).
- full-page-1440.png / full-page-390.png.
- overflow-report.json: comprobación de scroll horizontal por captura.

Datos ficticios. No es implementación ni captura de la aplicación.
No autoriza DEV22, esquema, commits, push, PR ni merge.